package com.chepegallego.chpbusca

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Paquetes {
    /** Arma el archivo para Claude en Descargas/MiBarra/ChpBusca/Claude/Enviados y devuelve su nombre. */
    fun crear(c: Context, correo: String, leeme: String, datos: String, fotos: String): String {
        val n = "ChpBusca_" + SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date()) + ".zip"
        val f = File(Carpeta.base("Claude/Enviados"), n)
        ZipOutputStream(FileOutputStream(f)).use { z ->
            z.putNextEntry(ZipEntry("LEEME_CLAUDE.txt")); z.write(leeme.toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("correo.json")); z.write(correo.toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("datos_chpbusca.json")); z.write(datos.toByteArray()); z.closeEntry()
            val arr = JSONArray(fotos)
            for (i in 0 until arr.length()) {
                val nombre = arr.getString(i)
                val ff = File(Fotos.dirInterno(c), nombre)
                if (!ff.exists()) continue
                z.putNextEntry(ZipEntry("fotos/$nombre"))
                ff.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        return n
    }

    /** Lee la respuesta de Claude: un .json suelto o un .zip que traiga un .json. */
    fun leer(c: Context, u: Uri): String {
        val bytes = c.contentResolver.openInputStream(u)!!.use { it.readBytes() }
        val esZip = bytes.size > 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()
        if (!esZip) {
            val t = bytes.toString(Charsets.UTF_8)
            JSONObject(t)
            return t
        }
        var json = ""
        ZipInputStream(bytes.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val nombre = e.name.substringAfterLast('/')
                if (!e.isDirectory && nombre.endsWith(".json") && json.isEmpty()) json = z.readBytes().toString(Charsets.UTF_8)
                e = z.nextEntry
            }
        }
        if (json.isEmpty()) throw IllegalStateException("sin json")
        JSONObject(json)
        return json
    }
}
