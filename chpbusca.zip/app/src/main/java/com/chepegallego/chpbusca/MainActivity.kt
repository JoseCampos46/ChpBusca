package com.chepegallego.chpbusca

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var cbFoto: String? = null
    private var cbZip: String? = null
    private var cbVoz: String? = null
    private var cbOido: String? = null
    private var segOido = 12
    private var grabadora: MediaRecorder? = null
    private val mano = Handler(Looper.getMainLooper())
    private val pararOido = Runnable { terminarOido() }

    private val escaner = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        devolverFoto(r.data?.getStringExtra("foto") ?: "")
    }
    private val galeria = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) devolverFoto("") else Thread {
            val n = try { Fotos.desdeUri(this, uri) } catch (e: Exception) { "" }
            runOnUiThread { devolverFoto(n) }
        }.start()
    }
    private val zipEntrada = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val cb = cbZip ?: return@registerForActivityResult
        cbZip = null
        if (uri == null) { js("$cb('')"); return@registerForActivityResult }
        Thread {
            val r = try { Paquetes.leer(this, uri) } catch (e: Exception) { "" }
            js("$cb(${JSONObject.quote(r)})")
        }.start()
    }
    private val voz = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: ""
        val cb = cbVoz ?: return@registerForActivityResult
        cbVoz = null
        js("$cb(${JSONObject.quote(t)})")
    }
    private val permisoMicro = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) empezarOido() else darOido("ERR:permiso")
    }

    private fun devolverFoto(n: String) {
        val cb = cbFoto ?: return
        cbFoto = null
        js("$cb(${JSONObject.quote(n)})")
    }

    private fun darOido(t: String) {
        val cb = cbOido ?: return
        cbOido = null
        js("$cb(${JSONObject.quote(t)})")
    }

    private fun archivoOido() = File(cacheDir, "oido.aac")

    @Suppress("DEPRECATION")
    private fun empezarOido() {
        try {
            val f = archivoOido()
            f.delete()
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioChannels(1)
            r.setAudioEncodingBitRate(64000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            grabadora = r
            js("oidoEmpezo()")
            mano.postDelayed(pararOido, segOido * 1000L)
        } catch (e: Exception) {
            grabadora = null
            darOido("ERR:micro")
        }
    }

    private fun terminarOido() {
        mano.removeCallbacks(pararOido)
        val r = grabadora ?: return
        grabadora = null
        try { r.stop() } catch (e: Exception) { }
        try { r.release() } catch (e: Exception) { }
        Thread {
            val f = archivoOido()
            val t = if (f.exists() && f.length() > 2000) Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) else "ERR:vacio"
            f.delete()
            runOnUiThread { darOido(t) }
        }.start()
    }

    fun js(c: String) = runOnUiThread { web.evaluateJavascript(c, null) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.textZoom = 100
        web.addJavascriptInterface(Puente(), "Android")
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url
                if (u.host != "app.local") return null
                val p = (u.path ?: "/").trimStart('/')
                return try {
                    if (p.startsWith("foto/")) {
                        val f = File(Fotos.dirInterno(this@MainActivity), p.removePrefix("foto/"))
                        WebResourceResponse("image/webp", null, FileInputStream(f))
                    } else {
                        val a = if (p.isEmpty()) "index.html" else p
                        val mime = when {
                            a.endsWith(".html") -> "text/html"
                            a.endsWith(".js") -> "application/javascript"
                            a.endsWith(".css") -> "text/css"
                            else -> "application/octet-stream"
                        }
                        WebResourceResponse(mime, "utf-8", assets.open(a))
                    }
                } catch (e: Exception) {
                    WebResourceResponse("text/plain", "utf-8", 404, "No", mapOf(), "".byteInputStream())
                }
            }

            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                if (u.host == "app.local") return false
                if (!req.isForMainFrame) return false
                abrirFuera(u.toString())
                return true
            }
        }
        web.loadUrl("https://app.local/index.html")
        // Atrás: cierra la hoja abierta; si no hay nada abierto, la app solo se minimiza (no se cierra).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("atras()") { r -> if (r != "true") moveTaskToBack(true) }
            }
        })
    }

    override fun onDestroy() {
        mano.removeCallbacks(pararOido)
        try { grabadora?.release() } catch (e: Exception) { }
        grabadora = null
        super.onDestroy()
    }

    private fun abrirFuera(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { }
    }

    inner class Puente {
        private val ctx: Activity get() = this@MainActivity

        @Suppress("DEPRECATION")
        @JavascriptInterface fun version(): String =
            try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

        @JavascriptInterface fun cargar(): String = Datos.cargar(ctx)
        @JavascriptInterface fun guardar(j: String) = Datos.guardar(ctx, j)
        @JavascriptInterface fun ajuste(k: String): String = Ajustes.leer(ctx, k)
        @JavascriptInterface fun ponerAjuste(k: String, v: String) = Ajustes.poner(ctx, k, v)

        @JavascriptInterface fun pedir(url: String, metodo: String, cuerpo: String, cb: String) {
            Thread {
                val r = Red.pedir(url, metodo, cuerpo)
                js("$cb(${JSONObject.quote(r)})")
            }.start()
        }

        @JavascriptInterface fun escanear(modo: String, cb: String) {
            cbFoto = cb
            runOnUiThread { escaner.launch(Intent(ctx, EscanerActivity::class.java).putExtra("modo", modo)) }
        }

        @JavascriptInterface fun deGaleria(cb: String) {
            cbFoto = cb
            runOnUiThread { galeria.launch("image/*") }
        }

        @JavascriptInterface fun fotoBase64(n: String): String = Fotos.base64(ctx, n)
        @JavascriptInterface fun borrarFoto(n: String) = Fotos.borrar(ctx, n)

        @JavascriptInterface fun dictar(cb: String) {
            cbVoz = cb
            runOnUiThread {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Dígame qué busca")
                try { voz.launch(i) } catch (e: Exception) {
                    cbVoz = null
                    js("$cb('ERR:voz')")
                }
            }
        }

        @JavascriptInterface fun escuchar(seg: Int, cb: String) {
            cbOido = cb
            segOido = seg.coerceIn(5, 30)
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) empezarOido()
                else permisoMicro.launch(Manifest.permission.RECORD_AUDIO)
            }
        }

        @JavascriptInterface fun pararEscucha() = runOnUiThread { terminarOido() }

        @JavascriptInterface fun abrir(url: String) = runOnUiThread { abrirFuera(url) }

        @JavascriptInterface fun copiar(t: String) {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("ChpBusca", t))
        }

        @JavascriptInterface fun crearPaquete(correo: String, leeme: String, datos: String, fotos: String): String =
            try { Paquetes.crear(ctx, correo, leeme, datos, fotos) } catch (e: Exception) { "" }

        @JavascriptInterface fun cargarRespuesta(cb: String) {
            cbZip = cb
            runOnUiThread { zipEntrada.launch("*/*") }
        }

        /** La X de arriba: ahí sí se cierra del todo. */
        @JavascriptInterface fun cerrar() = runOnUiThread { finishAndRemoveTask() }
    }
}
