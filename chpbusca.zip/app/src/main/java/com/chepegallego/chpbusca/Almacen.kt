package com.chepegallego.chpbusca

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Todo queda en Descargas/MiBarra/ChpBusca. Si la carpeta no existe (o la movieron a la nube) se vuelve a crear. */
object Carpeta {
    fun base(sub: String = ""): File {
        val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            if (sub.isEmpty()) "MiBarra/ChpBusca" else "MiBarra/ChpBusca/$sub")
        if (!d.exists()) d.mkdirs()
        return d
    }
}

object Datos {
    fun cargar(c: Context): String {
        val f = File(c.filesDir, "datos.json")
        if (f.exists()) return f.readText()
        return try {
            val e = File(Carpeta.base(), "datos.json")
            if (e.exists()) e.readText() else ""
        } catch (x: Exception) { "" }
    }

    fun guardar(c: Context, j: String) {
        File(c.filesDir, "datos.json").writeText(j)
        try { File(Carpeta.base(), "datos.json").writeText(j) } catch (x: Exception) { }
    }
}

/** Las llaves solo se guardan dentro del celular (nunca en Descargas ni en GitHub). */
object Ajustes {
    private fun p(c: Context) = c.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    fun leer(c: Context, k: String): String = p(c).getString(k, "") ?: ""
    fun poner(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
}

object Red {
    /** Devuelve {"c": código, "b": cuerpo}. c = 0 si no hubo conexión. */
    fun pedir(url: String, metodo: String, cuerpo: String): String {
        val r = JSONObject()
        try {
            val cx = URL(url).openConnection() as HttpURLConnection
            cx.requestMethod = metodo
            cx.connectTimeout = 20000
            cx.readTimeout = 90000
            cx.setRequestProperty("Accept", "application/json")
            if (cuerpo.isNotEmpty()) {
                cx.doOutput = true
                cx.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                cx.outputStream.use { it.write(cuerpo.toByteArray(Charsets.UTF_8)) }
            }
            val code = cx.responseCode
            val s = (if (code in 200..299) cx.inputStream else cx.errorStream)
            val t = s?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            cx.disconnect()
            r.put("c", code); r.put("b", t)
        } catch (e: Exception) {
            r.put("c", 0); r.put("b", e.message ?: "sin conexión")
        }
        return r.toString()
    }
}

object Fotos {
    fun dirInterno(c: Context): File = File(c.filesDir, "fotos").apply { mkdirs() }

    @Suppress("DEPRECATION")
    private fun formato(): Bitmap.CompressFormat =
        if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP

    fun escalar(b: Bitmap, max: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= max) return b
        val k = max.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true)
    }

    fun rotar(b: Bitmap, g: Float): Bitmap =
        if (g == 0f) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(g) }, true)

    /** Fotos livianas: máximo 1600 px, para que Gemini las lea rápido y no pesen. */
    fun guardar(c: Context, original: Bitmap, prefijo: String): String {
        val bmp = escalar(original, 1600)
        val n = prefijo + "_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".webp"
        val f = File(dirInterno(c), n)
        FileOutputStream(f).use { bmp.compress(formato(), 75, it) }
        FileOutputStream(File(dirInterno(c), "t_$n")).use { escalar(bmp, 320).compress(formato(), 60, it) }
        try { f.copyTo(File(Carpeta.base("fotos"), n), true) } catch (e: Exception) { }
        return n
    }

    fun desdeUri(c: Context, u: Uri): String {
        val op = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, op) }
        var s = 1
        while (maxOf(op.outWidth, op.outHeight) / (s * 2) >= 1600) s *= 2
        val b = c.contentResolver.openInputStream(u)!!.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        } ?: throw IllegalStateException("sin imagen")
        val giro = try {
            c.contentResolver.openInputStream(u)!!.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            }
        } catch (e: Exception) { 0f }
        return guardar(c, rotar(b, giro), "gal")
    }

    fun base64(c: Context, n: String): String {
        val f = File(dirInterno(c), n)
        if (!f.exists()) return ""
        return Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
    }

    fun borrar(c: Context, n: String) {
        File(dirInterno(c), n).delete()
        File(dirInterno(c), "t_$n").delete()
    }
}
