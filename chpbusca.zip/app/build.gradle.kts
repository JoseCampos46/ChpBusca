plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val numero = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
android {
    namespace = "com.chepegallego.chpbusca"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.chepegallego.chpbusca"
        minSdk = 28
        targetSdk = 34
        versionCode = numero
        versionName = "ChpBusca v1.${numero - 1}"
    }
    signingConfigs {
        create("fija") {
            storeFile = file("chpbusca.keystore")
            storePassword = "chpbusca2026"
            keyAlias = "chpbusca"
            keyPassword = "chpbusca2026"
        }
    }
    buildTypes {
        getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("fija") }
        getByName("debug") { signingConfig = signingConfigs.getByName("fija") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    val cx = "1.3.4"
    implementation("androidx.camera:camera-core:$cx")
    implementation("androidx.camera:camera-camera2:$cx")
    implementation("androidx.camera:camera-lifecycle:$cx")
    implementation("androidx.camera:camera-view:$cx")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
}
